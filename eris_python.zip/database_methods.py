import mysql.connector
from mysql.connector import errorcode
import mysql_con


def create_table(table_name, lst_column, lst_type, lst_column_length):    
    query1 = 'create table ' + table_name + ' ('
    #print table_name
    query2 = ''
    lst_length = -1

    if len(lst_column) == len(lst_type) and len(lst_type) == len(lst_column_length):
        lst_length = len(lst_column)
    else:
        print table_name + ' has ' + str(len(lst_column)) + 'columns'
        print ', but some records have ' + str(len(lst_column_length)) + ' fields'
        print ', delimiting was not sucessful.'
    for i in range(0, lst_length):
        query2 = query2 + lst_column[i] + ' ' + lst_type[i] + '(' + str(lst_column_length[i]) + ')'
        if i < lst_length-1:
            query2 = query2 + ','
    query3 = ')'    
    query = query1+query2+query3
    print query
    '''
    query = "CREATE TABLE keidi (jeff   varchar(4000) ) ENGINE=InnoDB"
    '''
    cnx = mysql_con.get_connection()
    cursor = cnx.cursor()
    #cursor.execute(query)
    #cursor.close()
    cnx.close()

def insert_one_row(table_name, lst_field):
    query1 = 'insert into ' + table_name + ' values ('
    query2 = ''
    lst_length = len(lst_field)
    for i in range(0, lst_length):
        query2 = query2 + "'" + lst_field[i] + "'"
        if i < lst_length-1:
            query2 = query2 + ','
    query3 = ')'
    query = query1 + query2 + query3
    #print query
    cnx = mysql_con.get_connection()
    cursor = cnx.cursor()
    cursor.execute(query)
    cursor.execute('commit')
    cursor.close()
    cnx.close()


def insert_rows(table_name, lst_lst_field, int_start_row):
    query1 = 'insert into ' + table_name + ' values ('
    
    query3 = ')'
    cnx = mysql_con.get_connection()
    cursor = cnx.cursor()
    for i in range(int_start_row, len(lst_lst_field)):
        row = lst_lst_field[i]
        query2 = ''
        for j in range(len(row)):
            query2 = query2 + "'" + escape_single_quotation(row[j]) + "'"
            if j < len(row)-1:
                query2 = query2 + ','
        query = query1 + query2 + query3    
        print query
        cursor.execute(query)
    cursor.execute('commit')
    cursor.close()
    cnx.close()

def escape_single_quotation(str_name):
    str_string = str_name.replace("'", "''")
    return str_string

'''    
TABLES = {}
TABLES['jeff'] = (
    "CREATE TABLE marina ("
    "  jeff varchar(4000) "
    ") ENGINE=InnoDB")
'''


'''
cnx = mysql_con.get_connection()

cursor = cnx.cursor()

for name, ddl in TABLES.iteritems():
    try:
        print("Creating table {}: ".format(name))
        cursor.execute(ddl)
        #cursor.execute('commit')
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

cursor.close()
cnx.close()
'''
if __name__ == '__main__':
    table_name = 'Formerly_Used_Defense_site'
    lst_lst_parsed_file = ['Reference_ID', 'Box_Number']
    lst_field_type = ['varchar', 'varchar']
    lst_column_max_length = [5, 10]

    create_table(table_name, lst_lst_parsed_file, lst_field_type, lst_column_max_length)
        
