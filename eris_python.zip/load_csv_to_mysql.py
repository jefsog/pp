import read_file_methods
import database_methods

if __name__ == '__main__':
    
    directory = 'C:\eris_python\csv'
    lst_file = read_file_methods.read_directory(directory)
    for file_name in lst_file:
        #print file_name
        
        lst_line = read_file_methods.read_file(file_name)
        lst_lst_parsed_file = []
        for line in lst_line:
            lst_field = read_file_methods.parse_line_excel_csv(line)
            lst_lst_parsed_file.append(lst_field)
        
        lst_lst_parsed_file = read_file_methods.csv_reader
        lst_column_max_length = read_file_methods.get_fields_max_length(lst_lst_parsed_file)
        
        table_name = file_name[len(directory)+1:-4]
        table_name = table_name.replace(' ', '_')
        lst_field_type = read_file_methods.get_data_type(lst_column_max_length)
        
        lst_column_name = read_file_methods.add_underscore(lst_lst_parsed_file[0])

        
        print table_name
        #print lst_lst_parsed_file
        print lst_column_name
        print lst_field_type
        print lst_column_max_length
        
        for i in range(len(lst_lst_parsed_file)):
            if len(lst_lst_parsed_file[i]) == 13:
                print i
                print lst_lst_parsed_file[i]

        '''
        #database_methods.create_table(table_name, lst_column_name, lst_field_type, lst_column_max_length)
        #database_methods.insert_rows(table_name, lst_lst_parsed_file, 1)
        #print 'inserted'